import java.awt.FlowLayout;
import java.awt.Font;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class DdayCalculator extends JFrame {
//	
//	Calendar d_day = Calendar.getInstance();
//	Calendar today = Calendar.getInstance();
//	
//	public DdayCalculator() {
//
//		//PlanDTO plan = new PlanDTO("�ڸ��ٲٱ�", "����", "����", "���ǽ�", c, null);
//		
//		Font font = new Font(Font.DIALOG, Font.BOLD, 30);
//		setLayout(new FlowLayout());
//		JLabel lblToday = new JLabel();
//		lblToday.setFont(font);
//		
//		int month = today.get(Calendar. MONTH);
//		month++;
//		
//		String todayString = "" + today.get(Calendar.YEAR) + month +today.get(Calendar.DATE);
//		lblToday.setText(todayString);
//		
//		JLabel lblDday = new JLabel();
//		lblDday.setFont(font);
//		
//		d_day.set(2020, 5, 20);
//		
//		long dday = plan.getStart().getTimeInMillis() / (24*60*60*1000);
//		
//		long today1 = today.getTimeInMillis() / (24*60*60*1000);
//		
//		long sum = today1-dday;
//
//		
//		sum = Math.abs(sum);
////		lblDday.setText(plan.getPlanTitle()+"�ϴ� ���� " + sum +"�� ���ҽ��ϴ�.");
//		
//		add(lblDday);
//		
//		showFrame();
//	}
//
//	private void showFrame() {
//		setSize(400,200);
//		setDefaultCloseOperation(EXIT_ON_CLOSE);
//		setVisible(true);
//	}
//	public static void main(String[] args) {
//		new DdayCalculator();
//	}

}
