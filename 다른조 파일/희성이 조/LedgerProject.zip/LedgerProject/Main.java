import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.*;
import java.time.chrono.JapaneseChronology;
import java.util.*;
import java.util.regex.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.basic.*;

public class Main extends JFrame {
	private JButton btnLeft, btnRight;
	private JLabel lblyear, lblmonth, lblInfo;
	private JButton btnLeftYear, btnRightYear;
	private JTabbedPane tab;
	private JButton btnAdd, btnToday;
	private JPanel pnlNorth, pnlCenter;
	private JPanel pnlNorthLine1, pnlNorthLine2;

	private JComboBox cbYear, cbMonth;
	private Calendar todayCal = Calendar.getInstance();

	private TabDaily daily;
	private TabCalendar calendarTab;
	private TabWeekly weekly;
	private TabMonthly monthly;
	private TabCategory category;
	private Main main = Main.this;
  
	private int year;
	private int month;
	private int y;
	private int m;
 
	public Main() {
		init();
		setDisplay(); 
		showFrame();
		fileLoad();
	}
 
	private void init() {
		Toolkit tk = Toolkit.getDefaultToolkit();
		this.setIconImage(tk.getImage("book-icon.png"));
		
		UIManager.put("ButtonUI", UI_SelectButton.class.getName()); 
		UIManager.put("Panel.background", new Color(0xf5f5f5));
		UIManager.put("OptionPane.background", new Color(0xf5f5f5));
		UIManager.put("ScrollBarUI", UI_ScrollBar.class.getName());
	    UIManager.put("ScrollBar.thumb", Color.PINK);
	    UIManager.put("ScrollBar.thumbDarkShadow", new Color(0xdb7093));
	    UIManager.put("ScrollBar.thumbShadow", Color.PINK);
	    UIManager.put("ScrollBar.thumbHighlight", Color.PINK);
	    UIManager.put("ToolTip.background", Color.WHITE);
	    UIManager.put("ToolTip.border", new LineBorder(Color.PINK,1)); 
		
		tab = new JTabbedPane();

		btnLeftYear = new JButton("<<");
		btnLeftYear.setUI(new UI_PrevNextButton());
		btnLeftYear.setPreferredSize(new Dimension(45, 24));
		btnLeft = new JButton("<");
		btnLeft.setUI(new UI_PrevNextButton());
		lblyear = new JLabel("��");
		lblmonth = new JLabel("��");
		btnRight = new JButton(">");
		btnRight.setUI(new UI_PrevNextButton());
		btnRightYear = new JButton(">>");
		btnRightYear.setUI(new UI_PrevNextButton());
		btnRightYear.setPreferredSize(new Dimension(45, 24));
		
		lblInfo = new JLabel(new ImageIcon("info-icon.png"), JLabel.LEFT);
		lblInfo.setToolTipText("<html>1. ���� �߰� : [Add] ��ư Ŭ�� �� [����/����] �� ����� �з��� �����Ͽ� ������ ������ �ּ���."
				+ "<br>2. ���� ���� : [Calendar] �ǿ��� �ش� ��¥�� ���� �� �����Ͻ� �� �ֽ��ϴ�."
				+ "<br>3. [Now] ��ư�� Ŭ���ϸ� ������ ��¥�� ���ư��ϴ�.</html>");

		daily = new TabDaily();
		calendarTab = new TabCalendar(main, daily);
		weekly = new TabWeekly();
		monthly = new TabMonthly();
		category = new TabCategory();

		// 1900��~2100��
		cbYear = new JComboBox();
		cbYear.setUI(new UI_ComboBox());
		cbYear.setBackground(Color.WHITE);
		for (int i = 1900; i <= 2100; i++) {
			cbYear.addItem(i);
			
		}
		// 1��~12��
		cbMonth = new JComboBox();
		cbMonth.setUI(new UI_ComboBox());
		cbMonth.setBackground(Color.WHITE);
		for (int i = 0; i < 12; i++) {
			cbMonth.addItem(i + 1);
		}

		// ��,�� �⺻ ���ð��� ���� ��¥
		cbYear.setSelectedItem(todayCal.get(Calendar.YEAR));
		cbMonth.setSelectedItem(todayCal.get(Calendar.MONTH) + 1);

		btnAdd = new JButton("Add");
		btnAdd.setUI(new UI_SelectButton());
		btnAdd.setPreferredSize(new Dimension(80, 23));
		btnAdd.setFont(new Font(Font.DIALOG, Font.BOLD, 14));
		btnToday = new JButton("Now");
		btnToday.setUI(new UI_SelectButton());
		btnToday.setPreferredSize(new Dimension(80, 23));
		btnToday.setFont(new Font(Font.DIALOG, Font.BOLD, 14));

		pnlNorth = new JPanel(new BorderLayout());
	
		pnlNorthLine1 = new JPanel();
		pnlNorthLine2 = new JPanel();
		pnlCenter = new JPanel();

	}
	
	public int getCbYear() {
		return (int) cbYear.getSelectedItem();
	}

	public int getCbMonth() {
		return (int) cbMonth.getSelectedItem();
	}

	private void setDisplay() {
		year = (int) cbYear.getSelectedItem();
		month = (int) cbMonth.getSelectedItem();
		y = year;
		m = month;

		tab.setUI(new UI_MainTabbedPane());
		tab.setPreferredSize(new Dimension(650, 720));
		tab.addTab("Calender", calendarTab);
		tab.addTab("Daily", daily);
		tab.addTab("Weekly", weekly);
		tab.addTab("Monthly", monthly);
		tab.addTab("Category", category);
		
		JPanel pnlInfo = new JPanel();
		pnlInfo.add(lblInfo);
		pnlInfo.setBackground(Color.WHITE);

		pnlNorthLine1.add(btnLeftYear);
		pnlNorthLine1.add(btnLeft);
		pnlNorthLine1.add(cbYear);
		pnlNorthLine1.add(lblyear);
		pnlNorthLine1.add(cbMonth);
		pnlNorthLine1.add(lblmonth);
		pnlNorthLine1.add(btnRight);
		pnlNorthLine1.add(btnRightYear);
		
		JPanel pnlNorth1 = new JPanel(new BorderLayout());
		pnlNorth1.add(pnlInfo, BorderLayout.WEST);
		pnlNorth1.add(pnlNorthLine1, BorderLayout.CENTER);
		
		pnlNorthLine2.add(btnAdd);
		pnlNorthLine2.add(btnToday);
		pnlNorthLine1.setBackground(Color.WHITE);
		pnlNorthLine2.setBackground(Color.WHITE);
		

		pnlNorth.add(pnlNorth1, BorderLayout.NORTH);
		pnlNorth.setBackground(Color.WHITE);
		pnlNorth.add(pnlNorthLine2, BorderLayout.SOUTH);
		pnlCenter.add(tab, BorderLayout.CENTER);
		pnlCenter.setBackground(Color.WHITE);

		add(pnlNorth, BorderLayout.NORTH);
		add(pnlCenter, BorderLayout.CENTER);

		btnLeft.addActionListener(new MyListener());
		btnLeftYear.addActionListener(new MyListener());
		btnRight.addActionListener(new MyListener());
		btnRightYear.addActionListener(new MyListener());

		btnAdd.addActionListener(new MyListener());
		btnToday.addActionListener(new MyListener());

		cbYear.addItemListener(new MyListener());
		cbMonth.addItemListener(new MyListener());
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				int result = JOptionPane.showConfirmDialog(
						Main.this, 
						"�����Ͻðڽ��ϱ�?", 
						"����",
						JOptionPane.YES_NO_OPTION,
						JOptionPane.WARNING_MESSAGE
					);
				if(result == 0){
					System.exit(0);
				}
			}
		});
	}

	private class MyListener implements ActionListener, ItemListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			Object o = e.getSource();
			if (o == btnAdd) {
				new AddFrame(main, daily);
			} else if (o == btnToday) {
				cbYear.setSelectedItem(todayCal.get(Calendar.YEAR));
				cbMonth.setSelectedItem(todayCal.get(Calendar.MONTH) + 1);
			}
			year = y;
			month = m;
			if (o == btnLeft) {
				if (month <= 1) {
					if(year == 1900) {
						JOptionPane.showMessageDialog(Main.this, "1900�⵵�� �������Դϴ�.");
					} else {
						month = 12;
						year -= 1;
					}
				} else {
					month -= 1;
				}
			} else if (o == btnRight) {
				if (month >= 12) {
					if(year == 2100) {
						JOptionPane.showMessageDialog(Main.this, "2100�⵵�� �������Դϴ�.");
					} else {
						month = 1;
						year += 1;
					}
				} else {
					month += 1;
				}
			} else if (o == btnLeftYear) {
				year -= 1;
				if(year < 1900) {
					JOptionPane.showMessageDialog(Main.this, "1900�⵵�� �������Դϴ�.");
				}
			} else if (o == btnRightYear) {
				year += 1;
				if(year > 2100) {
					JOptionPane.showMessageDialog(Main.this, "2100�⵵�� �������Դϴ�.");
				}
			}

			cbMonth.setSelectedItem(month);
			cbYear.setSelectedItem(year);
		}

		// �޺��ڽ��� ��¥�� �ٲ�� �� ��¥�� �°� ������ �� �ҷ��� ����
		@Override
		public void itemStateChanged(ItemEvent e) {
			if (e.getStateChange() == ItemEvent.SELECTED) {
				// y,m�� ���� ��,�� �� �����ͼ� ���Ϻҷ��Ë� �Ķ���ͷ� �̿�
				y = (int) cbYear.getSelectedItem();
				m = (int) cbMonth.getSelectedItem();
				fileLoad();
			}
		}
	}

	public void fileLoad() {
		calendarTab.drawCalendar(y, m);
		dailydrawCategory();
		monthly.drawCalendar(y, m);
		weekly.drawCalendar(y, m);
		category.drawingCategory(y, m);
	}

	public void dailydrawCategory() {
		daily.setEmptySpace();
		File file = new File("Account.txt");

		FileReader fr = null;
		BufferedReader br = null;

		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (Exception e) {
			}
		}

		try {
			fr = new FileReader(file);
			br = new BufferedReader(fr);

			Vector<Account> vec = new Vector<Account>();
			String line = null;

			while ((line = br.readLine()) != null) {
				String[] temp = line.split("\\|");
				// ���� '��,��' �� �´� ��ü�鸸 ���� Vector�� �� �������
				if (temp[0].equals(String.valueOf(cbYear.getSelectedItem()))
						&& temp[1].equals(String.valueOf(cbMonth.getSelectedItem()))) {
					vec.add(new Account(temp[0], temp[1], temp[2], temp[3], temp[4], temp[5], temp[6]));
				}
			}
			// ������������
			Collections.sort(vec);
			// daily�� ���پ� �߰��߰��߰�
			for (int i = 0; i < vec.size(); i++) {
				daily.addLine(vec.get(i).getString());
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			MyUtils.closeAll(fr, br);
		}
	}

	private void showFrame() {
		setTitle("�����");
		pack();
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		setVisible(true);
	}

	public static void main(String[] args) {
		new Main();
	}
}

class TabCalendar extends JPanel {
	private Calendar cal = Calendar.getInstance();
	private Calendar grayCal = Calendar.getInstance();
	private Calendar todayCal = Calendar.getInstance();

	private int year, month, lastDay;
	private String[] weekdays = { "��", "��", "ȭ", "��", "��", "��", "��" };
	private JLabel[] lblDay;
	private JLabel[] lblIncome, lblExpense, lblTotal;
	private JPanel[] pnlDay;
	private JPanel pnlCenter = new JPanel(new GridLayout(0, 7));
	private MouseListener mListener, listener;
	
	private DecimalFormat formatter = new DecimalFormat("###,###");
	private Main main;
	private TabDaily daily;
	
	public TabCalendar(Main main, TabDaily daily) {
		this.main = main;
		this.daily = daily;
		init();
		setDispaly();
		addListener();
		fileLoad();
	}
	
	private void init() {
		// �⺻ ���ð��� ���� ��¥
		drawCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1);
	}

	private void setDispaly() {
		setBackground(new Color(0xf5f5f5));
		JPanel pnlWeek = new JPanel(new GridLayout(0, 7));
		pnlWeek.setBackground(new Color(0xffe4e1));

		for (int i = 0; i < weekdays.length; i++) {
			JLabel lbl = new JLabel(weekdays[i], JLabel.CENTER);
			lbl.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
			lbl.setBorder(new LineBorder(new Color(0xf5f5f5), 1));
			// �Ͽ���, ������� ���� �ٲٱ�
			if (i == 0) {
				lbl.setForeground(Color.RED);
			} else if (i == 6) {
				lbl.setForeground(Color.BLUE);
			}
			pnlWeek.add(lbl);
		}

 
		JPanel pnlAll = new JPanel(new BorderLayout());
		pnlAll.add(pnlWeek, BorderLayout.NORTH);
		pnlAll.add(pnlCenter, BorderLayout.CENTER);

		add(pnlAll);
	}

	private void addListener() {
		mListener = new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// ����Ŭ���ϸ� �� ���� �� �� �ִ� dialog
				if (e.getClickCount() == 2) {
					int day = 0;

					for (int i = 0; i < pnlDay.length; i++) {
						// Ŭ���� ��¥�� �Ѱ���~
						if (e.getSource() == pnlDay[i]) {
							day = Integer.valueOf(lblDay[i].getText());
						}
					}
					new CalendarDialog(year, month, day, main, daily);
				}
			}
		};
		for (int i = 0; i < pnlDay.length; i++) {
			pnlDay[i].addMouseListener(mListener);
		}
	}

	private void addMouseListener() {
		for (JPanel pnlDays : pnlDay) {
			listener = new MouseAdapter() {
				@Override
				public void mouseEntered(MouseEvent e) {
					pnlDays.setBorder(new LineBorder(Color.PINK, 2));
				}
				@Override
				public void mouseExited(MouseEvent e) {
					pnlDays.setBorder(new LineBorder(new Color(0xf5f5f5), 1));
				}
			};
			pnlDays.addMouseListener(listener);
		}
	}

	public void drawCalendar(int inputYear, int inputMonth) {
		this.year = inputYear;
		this.month = inputMonth;
		
		pnlCenter.removeAll();
		
		cal.set(inputYear, inputMonth-1, 1);

		// �ش� ���� ù ���� (�Ͽ���1~�����7)
		int firstDay = cal.get(Calendar.DAY_OF_WEEK);
		// �ش� ���� ������ ��(�� �ϼ�)
		int lastDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
		this.lastDay = lastDay;
		
		// �ش� ���� 1�� ������ �������� �� ���� ��¥�� ���� �� �ְ�..
		int pMonth = inputMonth-2;
		if(pMonth == -1) {
			pMonth = 11;
		}
		grayCal.set(inputYear, pMonth, 1);
		int pLastDay = grayCal.getActualMaximum(Calendar.DAY_OF_MONTH);
		
		pLastDay -= (firstDay-2);
		for (int i = 1; i < firstDay; i++) {
			JLabel pDay = new JLabel(""+pLastDay, JLabel.LEFT);
			pDay.setVerticalAlignment(JLabel.TOP);
			pDay.setForeground(Color.LIGHT_GRAY);
			pDay.setBorder(new EmptyBorder(5,0,0,0));
			pnlCenter.add(pDay);
			pnlCenter.setBackground(new Color(0xf5f5f5));
			pLastDay++;
		}
	
		lblDay = new JLabel[lastDay];
		lblIncome = new JLabel[lastDay];
		lblExpense = new JLabel[lastDay];
		lblTotal = new JLabel[lastDay];
		pnlDay = new JPanel[lastDay];

		for (int day = 0; day < lastDay; day++) {
			lblDay[day] = new JLabel(String.valueOf(day + 1), JLabel.LEFT);
			lblIncome[day] = new JLabel("", JLabel.CENTER);
			lblIncome[day].setForeground(Color.BLUE);
			lblExpense[day] = new JLabel("", JLabel.CENTER);
			lblExpense[day].setForeground(Color.RED);
			lblTotal[day] = new JLabel("", JLabel.CENTER);
			lblTotal[day].setForeground(Color.GRAY);
			
			// ���� ����
			if (inputYear == todayCal.get(Calendar.YEAR) && inputMonth == todayCal.get(Calendar.MONTH) + 1) {
				if (day == todayCal.get(Calendar.DATE) - 1) {
					lblDay[day].setOpaque(true);
					lblDay[day].setBackground(Color.ORANGE);
				}
			}
			
			// ��,�� ����
			cal.set(inputYear, inputMonth - 1, day);
			int Weekend = cal.get(Calendar.DAY_OF_WEEK);
			if (Weekend == 7) {
				lblDay[day].setForeground(Color.RED);
			} else if (Weekend == 6) {
				lblDay[day].setForeground(Color.BLUE);
			}
			pnlDay[day] = new JPanel(new GridLayout(4, 0));
			pnlDay[day].add(lblDay[day]);
			pnlDay[day].add(lblIncome[day]);
			pnlDay[day].add(lblExpense[day]);
			pnlDay[day].add(lblTotal[day]);
			pnlDay[day].setBorder(new LineBorder(new Color(0xf5f5f5), 1));
			pnlDay[day].setBackground(Color.WHITE);
			pnlDay[day].setPreferredSize(new Dimension(92, 110));

			pnlDay[day].addMouseListener(mListener);

			pnlCenter.add(pnlDay[day]);
		}
		
		// lastDay ���� �� �޷��� ������ ��ġ���� ��¥ �����ϱ�
		int nMonth = inputMonth+1;
		if(nMonth == 13) {
			pMonth = 1;
		}
		grayCal.set(inputYear, pMonth, 1);
		int calEnd = 43-lastDay;
		for (int i = 1; i < calEnd; i++) {
			JLabel nDay = new JLabel(""+i, JLabel.LEFT);
			nDay.setVerticalAlignment(JLabel.TOP);
			nDay.setForeground(Color.LIGHT_GRAY);
			nDay.setBorder(new EmptyBorder(5,0,0,0));
			pnlCenter.add(nDay);
			pnlCenter.setBackground(new Color(0xf5f5f5));
		}
		
		addMouseListener();
		fileLoad();
	}

	private void fileLoad() {
		int year = this.year;
		int month = this.month;

		File file = new File("Account.txt");
		if(!file.exists()){
			try {
				file.createNewFile();
			} catch (Exception e) {
				
			}
		}

		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(file);
			br = new BufferedReader(fr);

			int[] strIncome = new int[this.lastDay];
			int[] strExpense = new int[this.lastDay];
			String line = null;
			while ((line = br.readLine()) != null) {
				String[] temp = line.split("\\|");
				
				if (temp[0].equals(String.valueOf(year)) && temp[1].equals(String.valueOf(month))) {
					for (int iday = 1; iday <= this.lastDay; iday++) {
						if (temp[2].equals(String.valueOf(iday)) && temp[3].equals("income")) {
							strIncome[iday - 1] += Integer.valueOf(temp[6]);
						} else if (temp[2].equals(String.valueOf(iday)) && temp[3].equals("expense")) {
							strExpense[iday - 1] += Integer.valueOf(temp[6]);
						}
					}
				}
			}
			int total = 0;
			for (int i = 0; i < strIncome.length; i++) {
				if (strIncome[i] != 0 || strExpense[i] != 0) {
					total = strIncome[i] - strExpense[i];
					lblIncome[i].setText(formatter.format(strIncome[i]) + "��\n");
					lblExpense[i].setText(formatter.format(strExpense[i]) + "��\n");
					lblTotal[i].setText(formatter.format(total) + "��\n");
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			MyUtils.closeAll(br, fr);
		}
	}
}

class CalendarDialog extends JDialog {
	private JButton btnOk, btnDelete;
	private JPanel pnlCenter, pnl;
	private int year, month, day;
	private String title;
	
	private DecimalFormat formatter = new DecimalFormat("###,###");
	private int max = 10000;
	private String[][] strDelete = new String[max][8];
	
	private Main main;
	private TabDaily tabDaily;

	public CalendarDialog(int y, int m, int d, Main main, TabDaily tabDaily) {
		this.year = y;
		this.month = m;
		this.day = d;
		this.main = main;
		this.tabDaily = tabDaily;
		title = y + "�� " + m + "�� " + d + "��";
		init();
		fileLoad();
		setDisplay();
		addListener();
		showFrame();

	}

	private void init() {
		Toolkit tk = Toolkit.getDefaultToolkit();
		this.setIconImage(tk.getImage("book-icon.png"));
		
		btnOk = new JButton("Confirm");
		btnOk.setUI(new UI_SelectButton());
		pnlCenter = new JPanel(new GridLayout(0, 1));
		ScrollPane sp = new ScrollPane();
		sp.setPreferredSize(new Dimension(450, 150));
		sp.add(pnlCenter);
		pnl = new JPanel();
		pnl.setBackground(Color.WHITE);
		pnl.add(sp);
	}

	private void setDisplay() {
		add(pnl, BorderLayout.CENTER);
		add(btnOk, BorderLayout.SOUTH);
	}

	private void addListener() {
		btnOk.addActionListener((e) -> dispose());
	}

	private void fileLoad() {
		File file = new File("Account.txt");

		FileInputStream fis = null;
		InputStreamReader isr = null;
		BufferedReader br = null;

		try {
			fis = new FileInputStream(file);
			isr = new InputStreamReader(fis);
			br = new BufferedReader(isr);
			int i = 0;
			String line = null;
			while ((line = br.readLine()) != null) {
				JLabel lblLine = new JLabel("", JLabel.LEFT);

				JPanel pnllblLine = new JPanel();
				pnllblLine.setBackground(new Color(0xf5f5f5));
				
				JPanel pnlbtn = new JPanel(new FlowLayout(FlowLayout.RIGHT));
				pnlbtn.setBackground(new Color(0xf5f5f5));
				
				JPanel pnlLine = new JPanel(new BorderLayout());
				pnlLine.setBackground(new Color(0xf5f5f5));
				
				String[] temp = line.split("\\|");
				if (temp[0].equals(String.valueOf(year)) && temp[1].equals(String.valueOf(month))
						&& temp[2].equals(String.valueOf(day))) {
					if(temp[3].equals("income")) {
						i++;
						if (temp[7].equals(" ")) {
							lblLine.setText("[ ���� - " + temp[5] + " ]   " + " + "
									+ formatter.format(Integer.valueOf(temp[6])) + "�� " + "(" + temp[4] + ")");
						} else {
							lblLine.setText(
									"[ ���� - " + temp[5] + " ]   " + " + " + formatter.format(Integer.valueOf(temp[6])) + "�� "
											+ "(" + temp[4] + " : " + temp[7] + ")");
						}
					} else {
						i++;
						if (temp[7].equals(" ")) {
							lblLine.setText("[ ���� - " + temp[5] + " ]   " + " - "
									+ formatter.format(Integer.valueOf(temp[6])) + "�� " + "(" + temp[4] + ")");
						} else {
							lblLine.setText(
									"[	���� - " + temp[5] + " ]   " + " - " + formatter.format(Integer.valueOf(temp[6]))
											+ "�� " + "(" + temp[4] + " : " + temp[7] + ")");
						}
					}
					strDelete[i] = temp;
					btnDelete = new JButton("Delete");
					btnDelete.setUI(new UI_SelectButton());
					btnDelete.setPreferredSize(new Dimension(90,25));
					btnDelete.setActionCommand(String.valueOf(i));
					btnDelete.addActionListener(new MyActionListener());
					pnllblLine.add(lblLine);
					pnlbtn.add(btnDelete);
					pnlLine.add(pnllblLine, BorderLayout.WEST);
					pnlLine.add(pnlbtn, BorderLayout.EAST);
					pnlCenter.add(pnlLine);
				}
			}
			max = i;

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			MyUtils.closeAll(br, isr, fis);
		}
	}

	private class MyActionListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			for (int i = 1; i <= max; i++) {
				if (e.getActionCommand().equals(i + "")) {
					int result = JOptionPane.showConfirmDialog(null, "�����Ͻðڽ��ϱ�?", "����Ȯ��", JOptionPane.YES_NO_OPTION);
					if (result == 0) {
						accountDelete(strDelete[i]);
						dispose();
					}
				}
			}
		}
	}

	private void accountDelete(String[] str) {
		int count = 0;

		FileReader fr = null;
		BufferedReader br = null;
		Vector<Account> vec = new Vector<Account>();
		try {
			fr = new FileReader("Account.txt");
			br = new BufferedReader(fr);

			String line = null;
			while ((line = br.readLine()) != null) {
				String[] temp = line.split("\\|");
				
				if (!(temp[0].equals(str[0]) && temp[1].equals(str[1])
						&& temp[2].equals(str[2]) && temp[3].equals(str[3])
						&& temp[4].equals(str[4]) && temp[5].equals(str[5])
						&& temp[6].equals(str[6]) && temp[7].equals(str[7]) )) {
					vec.add(new Account(temp[0], temp[1], temp[2], temp[3], temp[4], temp[5], temp[6], temp[7]));
				} else {
					count++;
				}
				if (count > 1) {
					for(int i=1; i<count; i++) {
						if (temp[0].equals(str[0]) && temp[1].equals(str[1])
								&& temp[2].equals(str[2]) && temp[3].equals(str[3])
								&& temp[4].equals(str[4]) && temp[5].equals(str[5])
								&& temp[6].equals(str[6]) && temp[7].equals(str[7])) {
							vec.add(new Account(temp[0], temp[1], temp[2], temp[3], temp[4], temp[5], temp[6], temp[7]));
						}
					}
				}
			}
			Collections.sort(vec);
			count = 0;

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			FileWriter fw = null;
			try {
				fw = new FileWriter("Account.txt");
				for (int i = 0; i < vec.size(); i++) {
					fw.write(vec.get(i).getString2() + "\n");
					fw.flush();
				}
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				main.fileLoad();
				tabDaily.setEmptySpace();
				main.dailydrawCategory();
				MyUtils.closeAll(fr, br);
			}
		}
	}

	private void showFrame() {
		setTitle(title);
		setResizable(false);
		pack();
		setLocationRelativeTo(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setVisible(true);
	}
}

class TabDaily extends JPanel {
	private JLabel lblIncomeText, lblIncomeNum;
	private JLabel lblExpensesText, lblExpensesNum;
	private JLabel lblTotalText, lblTotalNum;
	
	private JPanel pnlIncome, pnlExpenses, pnlTotal;
	private JPanel pnlNorth, pnlLine;
	
	private JList<JPanel> list;
	private DefaultListModel<JPanel> model;
	private int income, expenses, total;
	private DecimalFormat formatter = new DecimalFormat("###,###");

	public TabDaily() {
		init();
		setDisplay();
	}

	public void addLine(String[] s) {
		pnlLine = new JPanel(new GridLayout(2,3));
		
		JLabel lblTimeText = new JLabel(" ");
		lblTimeText.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
		JLabel lblTimeNum = new JLabel(s[1] + "�� " + s[2] + "��");
		lblTimeNum.setBorder(BorderFactory.createEmptyBorder(0, 0, 30, 0));

		JLabel lblAccountsText = new JLabel("Accounts : ");
		lblAccountsText.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
		JLabel lblAccountsNum = new JLabel(s[4] + "   ");

		JLabel lblCategoryText = new JLabel("Category : ");
		lblCategoryText.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
		JLabel lblCategoryNum = new JLabel(s[5] + "   ");

		JLabel lblAmountText = new JLabel("Amount : ");
		lblAmountText.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
		JLabel lblAmountNum = new JLabel(formatter.format(Integer.valueOf(s[6])) + "��");

		if (s[3].equals("income")) {
			lblAmountNum.setForeground(Color.BLUE);
			setlblIncome(Integer.valueOf(s[6]));
		} else if (s[3].equals("expense")) {
			lblAmountNum.setForeground(Color.RED);
			setlblExpenses(Integer.valueOf(s[6]));
		}
		
		JPanel pnlTime = new JPanel();
		pnlTime.setBackground(Color.WHITE);
		JPanel pnlAccounts = new JPanel();
		pnlAccounts.setBackground(Color.WHITE);
		pnlAccounts.setBorder(new LineBorder(new Color(0xf5f5f5),1));
		JPanel pnlCategory = new JPanel();
		pnlCategory.setBackground(Color.WHITE);
		pnlCategory.setBorder(new LineBorder(new Color(0xf5f5f5),1));
		JPanel pnlAmount = new JPanel();
		pnlAmount.setBackground(Color.WHITE);
		pnlAmount.setBorder(new LineBorder(new Color(0xf5f5f5),1));

		pnlTime.add(lblTimeText);
		pnlTime.add(lblTimeNum);
		pnlAccounts.add(lblAccountsText);
		pnlAccounts.add(lblAccountsNum);
		pnlCategory.add(lblCategoryText);
		pnlCategory.add(lblCategoryNum);
		pnlAmount.add(lblAmountText);
		pnlAmount.add(lblAmountNum);
		
		JPanel pnlNorth = new JPanel(new FlowLayout(FlowLayout.LEFT));
		pnlNorth.setBorder(new LineBorder(new Color(0xf5f5f5),1));
		pnlNorth.setBackground(Color.WHITE);
		pnlNorth.add(pnlTime);
		
		JPanel pnlSouth = new JPanel(new GridLayout(1,0));
		pnlSouth.add(pnlAccounts);
		pnlSouth.add(pnlCategory);
		pnlSouth.add(pnlAmount);

		pnlLine.setPreferredSize(new Dimension(600, 70));
		pnlLine.add(pnlNorth, BorderLayout.NORTH);
		pnlLine.add(pnlSouth, BorderLayout.SOUTH);

		model.addElement(pnlLine);
		setlblTotal();
	}

	protected void setEmptySpace() {
		try {
			list.remove(pnlLine);
			model.removeAllElements();
			this.income = 0;
			this.expenses = 0;
			this.total = 0;
			setlblIncome(0);
			setlblExpenses(0);
			setlblTotal();
		} catch (Exception e) {
		}
	}

	protected void setlblIncome(int income) {
		this.income += income;
		lblIncomeNum.setText(formatter.format(this.income) + "��");
	}

	protected void setlblExpenses(int expenses) {
		this.expenses += expenses;
		lblExpensesNum.setText(formatter.format(this.expenses) + "��");
	}

	protected void setlblTotal() {
		total = income - expenses;
		lblTotalNum.setText(formatter.format(this.total) + "��");
	}

	private void init() {
		pnlIncome = new JPanel();
		pnlIncome.setBackground(new Color(0xf5f5f5));
		pnlIncome.setBackground(Color.WHITE);
		pnlExpenses = new JPanel();
		pnlExpenses.setBackground(new Color(0xf5f5f5));
		pnlExpenses.setBackground(Color.WHITE);
		pnlExpenses.setBorder(BorderFactory.createMatteBorder(0, 1, 0, 1, Color.PINK));
		pnlTotal = new JPanel(); 
		pnlTotal.setBackground(new Color(0xf5f5f5));
		pnlTotal.setBackground(Color.WHITE);

		model = new DefaultListModel<JPanel>();
		list = new JList<JPanel>(model);
		list.setVisibleRowCount(10);
		list.setCellRenderer(new MyListRenderer());
		list.setBackground(new Color(0xf5f5f5));
		list.setBorder(new LineBorder(new Color(0xf5f5f5), 1));
		pnlNorth = new JPanel(new GridLayout(1, 3));
		pnlNorth.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.PINK));

		lblIncomeText = setLabel("���� : ");
		lblIncomeNum = setLabel("0");
		lblIncomeNum.setForeground(Color.BLUE);
		lblExpensesText = setLabel("���� : ");
		lblExpensesNum = setLabel("0");
		lblExpensesNum.setForeground(Color.RED);
		lblTotalText = setLabel("�հ� : ");
		lblTotalNum = setLabel("0");
	}

	private JLabel setLabel(String title) {
		JLabel lbl = new JLabel(title);
		lbl.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
		return lbl;
	}

	private class MyListRenderer extends DefaultListCellRenderer {
		@Override
		public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected,
				boolean cellHasFocus) {
			JPanel pnl = new JPanel();
			
			pnl.setBackground(new Color(0xf5f5f5));

			JPanel h = (JPanel) value;
			pnl.add(h);
			return pnl;
		}
	}

	private void setDisplay() {
		setLayout(new BorderLayout());
		setBackground(new Color(0xf5f5f5));
		pnlIncome.add(lblIncomeText);
		pnlIncome.add(lblIncomeNum);
		pnlExpenses.add(lblExpensesText);
		pnlExpenses.add(lblExpensesNum);
		pnlTotal.add(lblTotalText);
		pnlTotal.add(lblTotalNum);

		pnlNorth.add(pnlIncome);
		pnlNorth.add(pnlExpenses);
		pnlNorth.add(pnlTotal);

		JScrollPane scroll = new JScrollPane(list);
		scroll.getVerticalScrollBar().setUI(new UI_ScrollBar());
		scroll.setBorder(new LineBorder(new Color(0xf5f5f5), 1));

		add(pnlNorth, BorderLayout.NORTH);
		add(scroll, BorderLayout.CENTER);

	}
}

class TabWeekly extends JPanel {
	private Calendar cal = Calendar.getInstance();

	private JLabel[] lblDay;
	private JLabel[] lblIncome, lblExpense;
	private JPanel[] pnlWeek, pnlWeekInEx;
	private JPanel pnlCenter;

	private int year, month;
	private int income, expense;
	private DecimalFormat formatter = new DecimalFormat("###,###");

	public TabWeekly() {
		setDispaly();
	}

	private void setDispaly() {
		setBackground(new Color(0xf5f5f5));
		
		pnlCenter = new JPanel(new GridLayout(0, 1));
		// �⺻ ���ð��� ���� ��¥
		drawCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1);
		add(pnlCenter);
	}

	public void drawCalendar(int inputYear, int inputMonth) {
		this.year = inputYear;
		this.month = inputMonth;

		int otherMonth = 0;

		pnlCenter.removeAll();

		// Calendar�� ��, ���� �Է¹��� ������ ����
		cal.set(Calendar.YEAR, inputYear);
		// Month�� 0���� 1���̶� -1 �������
		cal.set(Calendar.MONTH, inputMonth - 1);

		int lastWeek = cal.getActualMaximum(Calendar.WEEK_OF_MONTH);
		for (int week = 1; week <= lastWeek; week++) {
			lblDay = new JLabel[lastWeek];
			lblIncome = new JLabel[lblDay.length];
			lblExpense = new JLabel[lblDay.length];
			pnlWeek = new JPanel[lblDay.length];
			pnlWeekInEx = new JPanel[lblDay.length];

			cal.set(Calendar.WEEK_OF_MONTH, week);

			// �ش� ���� �����ϰ� �������� ���ϱ�
			// �Ͽ��Ͽ� �ش��ϴ� ��¥�� startDay�� ����
			cal.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
			int startDay = cal.get(Calendar.DAY_OF_MONTH);
			// ����Ͽ� �ش��ϴ� ��¥�� endDay�� ����
			cal.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);
			int endDay = cal.get(Calendar.DAY_OF_MONTH);

			// ���Ϻ��� ����
			lblDay[week - 1] = new JLabel("", JLabel.CENTER);
			lblDay[week - 1].setFont(new Font(Font.DIALOG, Font.BOLD, 15));
			lblDay[week - 1].setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));
			lblDay[week - 1].setBorder(new LineBorder(new Color(0xf5f5f5), 1));

			// ù° ���� ������ ��
			if (week == 1 && startDay > 6) {
				otherMonth = inputMonth - 1;
				if (inputMonth - 1 == 0) {
					otherMonth = 12;
				}
				lblDay[week - 1].setText(otherMonth + " / " + startDay + "  ~  " + inputMonth + " / " + endDay);
				// ������ ���� �������� ��
			} else if (week == lastWeek) {
				otherMonth = inputMonth + 1;
				if (inputMonth + 1 == 13) {
					otherMonth = 1;
				}
				lblDay[week - 1].setText(inputMonth + " / " + startDay + "  ~  " + otherMonth + " / " + endDay);
				if (lastWeek == 5 && endDay > startDay) {
					lblDay[week - 1].setText(inputMonth + " / " + startDay + "  ~  " + inputMonth + " / " + endDay);
				} 
			} else {
				lblDay[week - 1].setText(inputMonth + " / " + startDay + "  ~  " + inputMonth + " / " + endDay);
			}

			// ���� ����
			JLabel lblWeekName = new JLabel("  " + week + "���� ");
			lblWeekName.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
			lblWeekName.setVerticalAlignment(JLabel.CENTER);
			lblWeekName.setBorder(BorderFactory.createEmptyBorder(6, 0, 0, 0));

			// ������ �г�
			JPanel pnlWeekName = new JPanel();
			pnlWeekName.setBackground(Color.WHITE);
			pnlWeekName.add(lblWeekName);
			pnlWeekName.setBorder(new LineBorder(new Color(0xf5f5f5), 1));

			// ����
			lblIncome[week - 1] = new JLabel("+ 0", JLabel.CENTER);
			lblIncome[week - 1].setForeground(Color.BLUE);
			lblIncome[week - 1].setFont(new Font(Font.DIALOG, Font.BOLD, 13));
			lblIncome[week - 1].setBorder(new LineBorder(new Color(0xf5f5f5), 1));

			// ����
			lblExpense[week - 1] = new JLabel("- 0", JLabel.CENTER);
			lblExpense[week - 1].setForeground(Color.RED);
			lblExpense[week - 1].setFont(new Font(Font.DIALOG, Font.BOLD, 13));
			lblExpense[week - 1].setBorder(new LineBorder(new Color(0xf5f5f5), 1));

			// �� ���� Ʋ
			pnlWeek[week - 1] = new JPanel(new GridLayout(1, 0));
			pnlWeek[week - 1].add(lblDay[week - 1]);
			pnlWeek[week - 1].add(lblIncome[week - 1]);
			pnlWeek[week - 1].add(lblExpense[week - 1]);
			pnlWeek[week - 1].setBackground(Color.WHITE);
			pnlWeek[week - 1].setPreferredSize(new Dimension(600, 80));
			pnlWeek[week - 1].setBorder(new LineBorder(new Color(0xf5f5f5), 1));

			// ��ü Ʋ
			pnlWeekInEx[week - 1] = new JPanel(new GridLayout(2, 0));
			pnlWeekInEx[week - 1].add(pnlWeekName, BorderLayout.NORTH);
			pnlWeekInEx[week - 1].add(pnlWeek[week - 1], BorderLayout.SOUTH);
			pnlWeekInEx[week - 1].setBackground(new Color(0xf5f5f5));
			pnlWeekInEx[week - 1].setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
			pnlWeekInEx[week - 1].setPreferredSize(new Dimension(600, 110));

			pnlCenter.add(pnlWeekInEx[week - 1]);
			fileLoad(week, startDay, endDay, otherMonth, lastWeek);
			otherMonth = 0;

		}
	}

	private void fileLoad(int week, int startDay, int endDay, int otherMonth, int lastWeek) {
		int year = this.year;
		int month = this.month;

		int pmLastDay = 0;

		Vector<Integer> vec = new Vector<Integer>();

		Calendar c = Calendar.getInstance();

		File file = new File("Account.txt");

		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(file);
			br = new BufferedReader(fr);

			String line = null;
			while ((line = br.readLine()) != null) {
				String[] temp = line.split("\\|");
				// temp[0~7] ������� --> �⵵/��/��/�ڻ�/�з�/�ݾ�/����

				if (week == 1) {
					if (otherMonth == 12) {
						year -= 1;
					}
					c.set(year, otherMonth - 1, 1);
					// ������ ��������
					pmLastDay = c.getActualMaximum(Calendar.DAY_OF_MONTH);

					vec.add(year);
					vec.add(otherMonth + 1);
					vec.add(pmLastDay);
					vec.add(startDay);
					vec.add(endDay);

					comparison(temp, vec);
					vec.removeAllElements();

				} else if (lastWeek == week) {
					if (otherMonth == 1) {
						year += 1;
					}
					c.set(year, month - 1, 1);
					// �̹� ���� ��������
					pmLastDay = c.getActualMaximum(Calendar.DAY_OF_MONTH);
					if (lastWeek == 5 && endDay > startDay) {
						if (temp[0].equals("" + year) && temp[1].equals("" + month)) {
							int day = Integer.valueOf(temp[2]);
							comparison2(temp, day, startDay, endDay);
						}
					} else {
						vec.add(year);
						vec.add(otherMonth);
						vec.add(pmLastDay);
						vec.add(startDay);
						vec.add(endDay);
	
						comparison(temp, vec);
						vec.removeAllElements();
					}
					
				} else if (temp[0].equals("" + year) && temp[1].equals("" + month)) {
					int day = Integer.valueOf(temp[2]);
					comparison2(temp, day, startDay, endDay);
				}
			}
			lblIncome[week - 1].setText("+ " + formatter.format(income) + "��");
			lblExpense[week - 1].setText("- " + formatter.format(expense) + "��");
			income = 0;
			expense = 0;
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			MyUtils.closeAll(br, fr);
		}
	}

	private void comparison(String[] temp, Vector<Integer> vec) {
		int day = 0;

		int year = vec.get(0);
		int month = vec.get(1);
		int pmLastDay = vec.get(2);
		int startDay = vec.get(3);
		int endDay = vec.get(4);

		if (temp[0].equals("" + year) && temp[1].equals("" + (month - 1))) {
			day = Integer.valueOf(temp[2]);
			if (day >= startDay && day <= pmLastDay) {
				if (temp[3].equals("income")) {
					income += Integer.valueOf(temp[6]);
				} else {
					expense += Integer.valueOf(temp[6]);
				}
			}
		} else if (temp[0].equals("" + year) && temp[1].equals("" + month)) {
			day = Integer.valueOf(temp[2]);
			if (day <= endDay) {
				if (temp[3].equals("income")) {
					income += Integer.valueOf(temp[6]);
				} else {
					expense += Integer.valueOf(temp[6]);
				}
			}
		}
	}
	
	private void comparison2(String[] temp,int day, int startDay, int endDay) {
		if (day >= startDay && day <= endDay) {
			if (temp[3].equals("income")) {
				income += Integer.valueOf(temp[6]);
			} else {
				expense += Integer.valueOf(temp[6]);
			}
		}
	}
}

class TabMonthly extends JPanel {
	private int year, month;
	private Calendar cal = Calendar.getInstance();
	private int income = 0;
	private int expense = 0;
	private static final int NUM = 12;

	private JLabel[] lblMonth, lblIncome, lblExpense;
	private JPanel[] pnlMonth, pnlMonthly;
	private JPanel pnlCenter;
	private DecimalFormat formatter = new DecimalFormat("###,###");

	public TabMonthly() {
		setDispaly();
	}

	private void setDispaly() {
		setBackground(new Color(0xf5f5f5));
		
		pnlCenter = new JPanel(new GridLayout(0, 1));
	
		// �⺻ ���ð��� ���� ��¥
		drawCalendar(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1);

		add(pnlCenter);
	}

	public void drawCalendar(int inputYear, int inputMonth) {
		this.year = inputYear;
		this.month = inputMonth;

		lblMonth = new JLabel[NUM];
		lblIncome = new JLabel[NUM];
		lblExpense = new JLabel[NUM];
		pnlMonth = new JPanel[NUM];
		pnlMonthly = new JPanel[NUM];

		pnlCenter.removeAll();
		for (int i = 0; i < NUM; i++) {
			lblMonth[i] = new JLabel((i + 1) + "��", JLabel.CENTER);
			lblMonth[i].setFont(new Font(Font.DIALOG, Font.BOLD, 15));
			lblMonth[i].setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));

			lblIncome[i] = new JLabel("+ 0", JLabel.CENTER);
			lblIncome[i].setForeground(Color.BLUE);
			lblExpense[i] = new JLabel("- 0", JLabel.CENTER);
			lblExpense[i].setForeground(Color.RED);

			pnlMonth[i] = new JPanel(new GridLayout(1, 0));
			pnlMonth[i].add(lblMonth[i]);
			pnlMonth[i].add(lblIncome[i]);
			pnlMonth[i].add(lblExpense[i]);
			pnlMonth[i].setBackground(Color.WHITE);
			pnlMonth[i].setPreferredSize(new Dimension(600, 40));
//			pnlMonth[i].setBorder(new EtchedBorder(EtchedBorder.RAISED));

			pnlMonthly[i] = new JPanel();
			pnlMonthly[i].add(pnlMonth[i]);
			pnlMonthly[i].setBackground(new Color(0xf5f5f5));
			pnlMonthly[i].setBorder(BorderFactory.createEmptyBorder(6, 0, 0, 0));
			
			pnlCenter.add(pnlMonthly[i]);
			fileLoad(i);
		}
		pnlMonthly[month - 1].setBorder(new LineBorder(Color.PINK, 2));
	}

	private void fileLoad(int monthly) {
		int year = this.year;

		File file = new File("Account.txt");

		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(file);
			br = new BufferedReader(fr);

			String line = null;
			while ((line = br.readLine()) != null) {
				String[] temp = line.split("\\|");

				// temp[0~7] ������� --> �⵵/��/��/�ڻ�/�з�/�ݾ�/����
				if (temp[0].equals("" + year) && temp[1].equals("" + (monthly + 1))) {
					if (temp[3].equals("income")) {
						income += Long.valueOf(temp[6]);
					} else {
						expense += Long.valueOf(temp[6]);
					}
				}
			}
			lblIncome[monthly].setText(formatter.format(income) + "��");
			lblExpense[monthly].setText(formatter.format(expense) + "��");
			income = 0;
			expense = 0;
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			MyUtils.closeAll(br, fr);
		}
	}
}

class TabCategory extends JPanel {
	private String[] incomeCategory = { "�޿�", "�뵷", "�󿩱�", "���ʽ�", "����", "�ֽ�", "����", "�ε���", "����Ʈ/���ϸ���", "��Ÿ" };
	private String[] expenseCategory = { "�Ļ�", "ī��/����", "��Ȱ/��Ʈ", "����/����", "�ְ�/���", "�м�", "��Ƽ/�̿�", "�Ƿ�/�ǰ�", "�н�/����",
			"��ȭ/����", "������/ȸ��", "����", "����/����", "��/����", "��Ÿ" };
	private JComboBox cbCategory;
	private JLabel[] lblIC = new JLabel[incomeCategory.length];
	private JLabel[] lblICAmount = new JLabel[lblIC.length];
	private JLabel[] lblEC = new JLabel[expenseCategory.length];
	private JLabel[] lblECAmount = new JLabel[lblEC.length];
	
	private JPanel[] pnllbl, pnlCategory;
	private JPanel pnlCenter;
	
	private DecimalFormat formatter = new DecimalFormat("###,###");
	
	private Calendar cal = Calendar.getInstance();
	private int year, month;
	private String type = "����";
	
	public TabCategory() {
		init();
		setDisplay();
		addListener();
	}
	
	private void init() {		
		cbCategory = new JComboBox();
		cbCategory.setUI(new UI_ComboBox());
		cbCategory.setBackground(Color.WHITE);
		cbCategory.addItem("����");
		cbCategory.addItem("����");
		
		for(int i=0; i<lblIC.length; i++) {
			lblIC[i] = new JLabel(incomeCategory[i], JLabel.CENTER);
			lblIC[i].setBackground(Color.WHITE);
			lblIC[i].setBorder(new LineBorder(new Color(0xf5f5f5), 1));
			lblICAmount[i] = new JLabel("0��", JLabel.CENTER);
			lblICAmount[i].setForeground(Color.BLUE);
			lblICAmount[i].setBackground(Color.WHITE);
			lblICAmount[i].setBorder(new LineBorder(new Color(0xf5f5f5), 1));
		}
		for(int i=0; i<lblEC.length; i++) {
			lblEC[i] = new JLabel(expenseCategory[i], JLabel.CENTER);
			lblEC[i].setBackground(Color.WHITE);
			lblEC[i].setBorder(new LineBorder(new Color(0xf5f5f5), 1));
			lblECAmount[i] = new JLabel("0��", JLabel.CENTER);
			lblECAmount[i].setForeground(Color.RED);
			lblECAmount[i].setBackground(Color.WHITE);
			lblECAmount[i].setBorder(new LineBorder(new Color(0xf5f5f5), 1));
		}
	}
	
	private void setDisplay() {
		setBackground(new Color(0xf5f5f5));
		
		pnlCenter = new JPanel(new GridLayout(0,2));
		pnlCenter.setBackground(new Color(0xf5f5f5));
		
		// �⺻ ���ð��� ���� ��¥
		drawingCategory(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1);
		
		add(cbCategory, BorderLayout.NORTH);
		add(pnlCenter, BorderLayout.CENTER);
		
	}
	
	private void addListener() {
		ItemListener iListener = new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					type = (String) cbCategory.getSelectedItem();
					drawingCategory(year, month);
					revalidate();
					repaint();
				}
			}
		};
		cbCategory.addItemListener(iListener);
	}
	
	public void drawingCategory(int year, int month) {
		this.year = year;
		this.month = month;
		
		pnlCenter.removeAll();
		if (type.equals("����")) {
			pnllbl = new JPanel[lblIC.length];
			pnlCategory = new JPanel[lblIC.length];
			for(int i=0; i<lblIC.length; i++) {
				pnllbl[i] = new JPanel(new GridLayout(0,1));
				pnllbl[i].add(lblIC[i]);
				pnllbl[i].add(lblICAmount[i]);
				
				pnllbl[i].setBackground(Color.WHITE);
				pnllbl[i].setPreferredSize(new Dimension(300, 80));
				
				pnlCategory[i] = new JPanel();
				pnlCategory[i].add(pnllbl[i]);
				pnlCategory[i].setBackground(new Color(0xf5f5f5));
				pnlCategory[i].setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
				
				pnlCenter.add(pnlCategory[i]);
				fileLoad(lblIC[i].getText(), i);
			}
		} else {
			pnllbl = new JPanel[lblEC.length];
			pnlCategory = new JPanel[lblEC.length];
			for(int i=0; i<lblEC.length; i++) {
				pnllbl[i] = new JPanel(new GridLayout(0,1));
				pnllbl[i].add(lblEC[i]);
				pnllbl[i].add(lblECAmount[i]);
				
				pnllbl[i].setBackground(Color.WHITE);
				pnllbl[i].setPreferredSize(new Dimension(300, 60));
				
				pnlCategory[i] = new JPanel();
				pnlCategory[i].add(pnllbl[i]);
				pnlCategory[i].setBackground(new Color(0xf5f5f5));
				pnlCategory[i].setBorder(BorderFactory.createEmptyBorder(0, 0, 11, 0));
				
				pnlCenter.add(pnlCategory[i]);
				fileLoad(lblEC[i].getText(), i);
			}
		}
	}
	
	private void fileLoad(String category, int idx) {
		int total = 0;
		File file = new File("Account.txt");
		
		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(file);
			br = new BufferedReader(fr);

			String line = null;
			while ((line = br.readLine()) != null) {
				String[] temp = line.split("\\|");
				
				// temp[0~7] ������� --> �⵵/��/��/�ڻ�/�з�/�ݾ�/����
				if (temp[0].equals("" + year) && temp[1].equals("" + month)) {
					if(temp[5].equals(category)) {
						total += Integer.valueOf(temp[6]);
					}
				}
			}
			if(type.equals("����")) {
				lblICAmount[idx].setText(formatter.format(total) + "��");
			} else {
				lblECAmount[idx].setText(formatter.format(total) + "��");
			}
			total=0;
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			MyUtils.closeAll(br, fr);
		}
	}
}

class AddFrame extends JFrame {
	private JTabbedPane tab = new JTabbedPane();
	private AddFrame addFrame = AddFrame.this;
	private TabDaily daily;
	private Main main;

	public AddFrame(Main main, TabDaily daily) {
		this.main = main;
		this.daily = daily;
		init();
		setDisplay();
		showFrame();
	}

	private void init() {
		Toolkit tk = Toolkit.getDefaultToolkit();
		this.setIconImage(tk.getImage("book-icon.png"));
		
		tab.addTab("����",
				new AddTap(main, daily, addFrame, "income"));
		tab.setUI(new UI_SubTabbedPane());
		tab.addTab("����",
				new AddTap(main, daily, addFrame, "expense"));
	}

	private void setDisplay() {
		add(tab, BorderLayout.CENTER);
	}

	private void showFrame() {
		setTitle("���� ���");
		pack();
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setVisible(true);
	}
}

class AddTap extends JPanel {
	private Main main;
	private TabDaily tabDaily;
	private AddFrame addFrame;
	private JButton btnSave, btnCancel;
	private JLabel lblYear, lblMonth, lblDay;
	private JLabel lblDate, lblAccount, lblCategory, lblAmount, lblContents;
	private JRadioButton rbtnCash, rbtnCard;
	private String[] incomeCategory = { "�޿�", "�뵷", "�󿩱�", "���ʽ�", "�����ҵ�", "�ε���ҵ�", "�ֽ�", "����Ʈ/���ϸ���", "��Ÿ" };
	private String[] expenseCategory = { "�Ļ�", "ī��/����", "��Ȱ/��Ʈ", "����/����", "�ְ�/���", "�м�", "��Ƽ/�̿�", "�Ƿ�/�ǰ�", "�н�/����",
			"��ȭ/����", "������/ȸ��", "����", "����/����", "��/����", "��Ÿ" };
	private JComboBox cbCategory, cbYear, cbMonth, cbDay;
	private JTextField tfAmount, tfContents;
	private Calendar todayCal = Calendar.getInstance();
	// 1~12���� �� �ϼ�(= ������ ��)
	private String addType;

	public AddTap(Main main, TabDaily tabDaily, AddFrame addFrame, String addType) {
		this.main = main;
		this.tabDaily = tabDaily;
		this.addFrame = addFrame;
		this.addType = addType;
		init();
		setDisplay();
		addListener();
	}

	public void init() {
		btnSave = new JButton("Save");
		btnSave.setUI(new UI_SelectButton());
		btnCancel = new JButton("Cancel");
		btnCancel.setUI(new UI_SelectButton());
		lblYear = new JLabel("��");
		lblMonth = new JLabel("��");
		lblDay = new JLabel("��");

		// 1900��~2100��
		cbYear = new JComboBox();
		cbYear.setBackground(Color.WHITE);
		cbYear.setUI(new UI_ComboBox());
		for (int i = 1900; i <= 2100; i++) {
			cbYear.addItem(i);
		}
		// 1��~12��
		cbMonth = new JComboBox();
		cbMonth.setUI(new UI_ComboBox());
		cbMonth.setBackground(Color.WHITE);
		for (int i = 0; i < 12; i++) {
			cbMonth.addItem(i+1);
		}

		cbDay = new JComboBox();
		cbDay.setUI(new UI_ComboBox());
		cbDay.setBackground(Color.WHITE);
		todayCal.set(main.getCbYear(), main.getCbMonth()-1, 1);
		int m = todayCal.getActualMaximum(Calendar.DAY_OF_MONTH);
		for (int i = 0; i < m; i++) {
			cbDay.addItem(i + 1);
		}
		cbYear.setSelectedItem(Integer.valueOf(main.getCbYear()));
		cbMonth.setSelectedItem(Integer.valueOf(main.getCbMonth()));
		cbDay.setSelectedItem(todayCal.get(Calendar.DATE));

		lblDate = new JLabel("��¥", JLabel.LEFT);
		lblAccount = new JLabel("�ڻ�", JLabel.LEFT);
		lblCategory = new JLabel("�з�", JLabel.LEFT);
		lblAmount = new JLabel("�ݾ�", JLabel.LEFT);
		lblContents = new JLabel("����", JLabel.LEFT);

		rbtnCash = new JRadioButton("����");
		rbtnCash.setBackground(new Color(0xf5f5f5));
		rbtnCard = new JRadioButton("ī��");
		rbtnCard.setBackground(new Color(0xf5f5f5));
		ButtonGroup group = new ButtonGroup();
		group.add(rbtnCash);
		group.add(rbtnCard);


		if (addType == "income") {
			cbCategory = new JComboBox(incomeCategory);
		} else if (addType == "expense") {
			cbCategory = new JComboBox(expenseCategory);
		}
		cbCategory.setUI(new UI_ComboBox());
		cbCategory.setBackground(Color.WHITE);
		
		tfAmount = new JTextField(23);
		tfAmount.setBorder(new LineBorder(Color.PINK));
		tfAmount.setPreferredSize(new Dimension(0, 24));
		tfContents = new JTextField(23);
		tfContents.setBorder(new LineBorder(Color.PINK));
		tfContents.setPreferredSize(new Dimension(0, 24));
	}

	private void setDisplay() {
		JPanel pnlDate = new JPanel();
		pnlDate.add(cbYear);
		pnlDate.add(lblYear);
		pnlDate.add(cbMonth);
		pnlDate.add(lblMonth);
		pnlDate.add(cbDay);
		pnlDate.add(lblDay);

		JPanel pnlRbtnGr = new JPanel();
		pnlRbtnGr.add(rbtnCash);
		pnlRbtnGr.add(rbtnCard);
		
		JPanel pnlCategory = new JPanel();
		cbCategory.setPreferredSize(new Dimension(256, 26));
		pnlCategory.add(cbCategory);
		
		JPanel pnltfAmount = new JPanel();
		pnltfAmount.add(tfAmount);
		
		JPanel pnltfContents = new JPanel();
		pnltfContents.add(tfContents);
		
		JPanel pnlCEast = new JPanel(new GridLayout(0, 1));
		pnlCEast.add(pnlDate);
		pnlCEast.add(pnlRbtnGr);
		pnlCEast.add(pnlCategory);
		pnlCEast.add(pnltfAmount);
		pnlCEast.add(pnltfContents);
		pnlCEast.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));

		JPanel pnlCWest = new JPanel(new GridLayout(0, 1));
		pnlCWest.add(lblDate);
		pnlCWest.add(lblAccount);
		pnlCWest.add(lblCategory);
		pnlCWest.add(lblAmount);
		pnlCWest.add(lblContents);
		pnlCWest.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
		
		JPanel pnlSouth = new JPanel();
		pnlSouth.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
		pnlSouth.add(btnSave);
		pnlSouth.add(btnCancel);

		JPanel pnlC = new JPanel(new BorderLayout());
		pnlC.add(pnlCWest, BorderLayout.WEST);
		pnlC.add(pnlCEast, BorderLayout.EAST);
		pnlC.add(pnlSouth, BorderLayout.SOUTH);
		pnlC.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

		add(pnlC, BorderLayout.CENTER);
	}

	private void addListener() {
		ItemListener iListener = new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					int d = (int) cbDay.getSelectedItem();
					cbDay.removeAllItems();
					int m = (int) cbMonth.getSelectedItem();
					int y = (int) cbYear.getSelectedItem();

					todayCal.set(y, m - 1, 1);
					int lastDay = todayCal.getActualMaximum(Calendar.DAY_OF_MONTH);

					for (int day = 0; day < lastDay; day++) {
						cbDay.addItem(day + 1);
					}
					cbDay.setSelectedItem(d);
				}
			}
		};
		cbMonth.addItemListener(iListener);
		cbYear.addItemListener(iListener);

		ActionListener alistener = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object o = e.getSource();
				if (o == btnSave) {
					btnfileSave();
				} else if (o == btnCancel) {
					addFrame.dispose();
				}
			}
		};

		btnSave.addActionListener(alistener);
		btnCancel.addActionListener(alistener);
	}

	private void btnfileSave() {
		boolean SaveCheck = true;

		int year = (int) cbYear.getSelectedItem();
		int month = (int) cbMonth.getSelectedItem();
		int day = (int) cbDay.getSelectedItem();

		String account = rbtnCash.isSelected() ? "����" : "ī��";
		String category = (String) cbCategory.getSelectedItem();
		String amount = tfAmount.getText();
		String countents = tfContents.getText();

		if (rbtnCash.isSelected() == false && rbtnCard.isSelected() == false) {
			JOptionPane.showMessageDialog(this, "�ڻ��� �����ϼ���");
			SaveCheck = false;
		} else if ((tfAmount.getText().trim()).isEmpty()) {
			JOptionPane.showMessageDialog(this, "�ݾ��� �Է��ϼ���");
			SaveCheck = false;
		} else if (!(Pattern.matches("^[0-9]+$", amount))) {
			JOptionPane.showMessageDialog(this, "�ݾ��� ���ڸ� �Է� �����մϴ�");
			SaveCheck = false;
		} else if ((tfContents.getText().trim()).isEmpty()) {
			countents = " ";
		}
		
		if (SaveCheck && !(tfAmount.getText().trim()).isEmpty()) {
			try {
				Integer.valueOf(tfAmount.getText());
			} catch (NumberFormatException e) {
				JOptionPane.showMessageDialog(this, "�ݾ��� �ʹ� �����ϴ�.");
				SaveCheck = false;
			}
		}
		
		if (SaveCheck) {
			String info = year + "|" + month + "|" + day + "|" + addType
						+ "|"+ account + "|" + category + "|" + amount
						+ "|" + countents + "|";
			
			FileWriter fw = null;
			try {
				fw = new FileWriter("Account.txt", true);
				fw.write(info + "\n");
				fw.flush();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				MyUtils.closeAll(fw);
				main.fileLoad();
				addFrame.dispose();
			}
		}
	}
}


class Account implements Comparable<Account> {
	// �����Ҷ� ���� ��
	int year;
	int month;
	int day;

	// ���� �Ķ���ͷ� �Ѱ��༭ ����Ұ�
	String[] str = new String[8];

	public Account(String year, String month, String day, String addType, String account, String category,
			String amount) {
		str[0] = year;
		str[1] = month;
		str[2] = day;
		str[3] = addType;
		str[4] = account;
		str[5] = category;
		str[6] = amount;
		if (str[7] == null) {
			str[7] = " ";
		}
		this.year = Integer.valueOf(year);
		this.month = Integer.valueOf(month);
		this.day = Integer.valueOf(day);
	}

	public Account(String year, String month, String day, String addType, String account, String category,
			String amount, String countents) {
		str[0] = year;
		str[1] = month;
		str[2] = day;
		str[3] = addType;
		str[4] = account;
		str[5] = category;
		str[6] = amount;
		str[7] = countents;
		if (str[7] == null) {
			str[7] = " ";
		}
		this.year = Integer.valueOf(year);
		this.month = Integer.valueOf(month);
		this.day = Integer.valueOf(day);
	}

	public String[] getString() {
		return str;
	}

	public String getString2() {
		return year + "|" + month + "|" + day + "|" + str[3] + "|" + str[4]
				+ "|" + str[5] + "|" + str[6] + "|" + str[7] + "|";
	}

	public int getYear() {
		return year;
	}
	
	public int getMonth() {
		return month;
	}
	
	public int getDay() {
		return day;
	}

	// ��,��,�� �� ����
	@Override
	public int compareTo(Account other) {
		if (this.getYear() == other.getYear()) {
			if (this.getMonth() == other.getMonth()) {
				return this.getDay() - other.getDay();
			} else {
				return this.getMonth() - other.getMonth();
			}
		} else {
			return this.getYear() - other.getYear();
		}
	}
}

class MyUtils {
	public static void closeAll(Closeable... c) {
		for( Closeable temp : c ) {
			try {
				temp.close();
			} catch(Exception e) {}
		}
	}
}

// =============================== ���⼭���� UI ���� �ڵ�

class UI_Button extends BasicButtonUI implements SwingConstants {
    @Override
    public void installUI(JComponent c) {
        super.installUI(c);
        JButton button = (JButton) c;
        button.setContentAreaFilled(false);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
    }
}

class UI_ComboBox extends BasicComboBoxUI {
    @Override 
    public void installUI(JComponent c) {
    	super.installUI(c);

        JComboBox comboBox = (JComboBox) c;
        comboBox.setFocusable(true);
        comboBox.setOpaque(false);
        comboBox.setRenderer(new UI_ListCellRenderer());
    }

    @Override
    protected JButton createArrowButton() {
        JButton arrow = new JButton();
        arrow.setUI(new UI_Button());
        arrow.setIcon(new ImageIcon(("icon.png")));
        arrow.setFocusable(false); 
        arrow.setMargin(new Insets(0, 0, 0, 0));
        return arrow;
    }

    @Override
    public void paint(Graphics g, JComponent c) {

        JComboBox comboBox = (JComboBox) c;

        hasFocus = comboBox.hasFocus();

        Rectangle r = rectangleForCurrentValue();

        Graphics2D g2d = (Graphics2D) g;
        if (!comboBox.isEditable()) {
            paintCurrentValueBackground(g2d, r, hasFocus);
            paintCurrentValue(g2d, r, hasFocus);
        } else {
            paintCurrentValueBackground(g2d, r, hasFocus);
        }

        if (comboBox.hasFocus()) {
            g2d.setColor(Color.PINK);
        } else {
            g2d.setColor(Color.PINK);
        }
        g2d.drawRoundRect(0, 0, comboBox.getWidth() - 2, comboBox.getHeight() - 2, 2, 2);
    }
    
    @Override
    protected ComboPopup createPopup() {
        BasicComboPopup popup = (BasicComboPopup) super.createPopup();
        popup.setBorder(BorderFactory.createLineBorder(Color.PINK));
        
        return popup;
    }
}

class UI_ListCellRenderer implements ListCellRenderer {
    private DefaultListCellRenderer defaultCellRenderer = new DefaultListCellRenderer();

    @Override
    public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        JLabel renderer = (JLabel) defaultCellRenderer.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

        if (isSelected) {
            renderer.setBackground(Color.PINK);
            renderer.setForeground(Color.WHITE);
        } else {
        	renderer.setBackground(Color.WHITE);
        }
        renderer.setHorizontalAlignment(JLabel.CENTER);
        renderer.setPreferredSize(new Dimension(40, 25));

        list.setSelectionBackground(null);
        list.setBorder(null);

        return renderer;
    }
}

class UI_MainTabbedPane extends BasicTabbedPaneUI {
    private boolean tabsOverlapBorder = UIManager.getBoolean("TabbedPane.tabsOverlapBorder");
    private Color SELECT_COLOR = Color.PINK;
    private Color N_SELECT_COLOR = Color.WHITE;

    @Override
    protected void paintTabBorder(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {

    }

    @Override
    protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
        Graphics2D g2d = (Graphics2D) g;
        GradientPaint gradient;
        switch (tabPlacement) {
            case LEFT:
                if (isSelected) {
                    gradient = new GradientPaint(x + 1, y, SELECT_COLOR, x + w, y, Color.WHITE, true);
                } else {
                    gradient = new GradientPaint(x + 1, y, N_SELECT_COLOR, x + w, y, Color.WHITE, true);
                }
                g2d.setPaint(gradient);
                g.fillRect(x + 1, y + 1, w - 1, h - 2);
                break;
            case RIGHT:
                if (isSelected) {
                    gradient = new GradientPaint(x + w, y, SELECT_COLOR, x + 1, y, Color.WHITE, true);
                } else {
                    gradient = new GradientPaint(x + w, y, N_SELECT_COLOR, x + 1, y, Color.WHITE, true);
                }
                g2d.setPaint(gradient);
                g.fillRect(x, y + 1, w - 1, h - 2);
                break;
            case BOTTOM:
                if (isSelected) {
                    gradient = new GradientPaint(x + 1, y + h, SELECT_COLOR, x + 1, y, Color.WHITE, true);
                } else {
                    gradient = new GradientPaint(x + 1, y + h, N_SELECT_COLOR, x + 1, y, Color.WHITE, true);
                }
                g2d.setPaint(gradient);
                g.fillRect(x + 1, y, w - 2, h - 1);
                break;
            case TOP:
            default:
                if (isSelected) {
                    gradient = new GradientPaint(x + 1, y, SELECT_COLOR, x + 1, y + h, Color.WHITE, true);
                } else {
                    gradient = new GradientPaint(x + 1, y, N_SELECT_COLOR, x + 1, y + h, Color.WHITE, true);
                }
                g2d.setPaint(gradient);
                g2d.fillRect(x + 1, y + 1, w - 2, h - 1);
        }

    }

    @Override
    protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex) {
        int width = tabPane.getWidth();
        int height = tabPane.getHeight();
        Insets insets = tabPane.getInsets();
        Insets tabAreaInsets = getTabAreaInsets(tabPlacement);

        int x = insets.left;
        int y = insets.top;
        int w = width - insets.right - insets.left;
        int h = height - insets.top - insets.bottom;

        switch (tabPlacement) {
            case LEFT:
                x += calculateTabAreaWidth(tabPlacement, runCount, maxTabWidth);
                if (tabsOverlapBorder) {
                    x -= tabAreaInsets.right;
                }
                w -= (x - insets.left);
                break;
            case RIGHT:
                w -= calculateTabAreaWidth(tabPlacement, runCount, maxTabWidth);
                if (tabsOverlapBorder) {
                    w += tabAreaInsets.left;
                }
                break;
            case BOTTOM:
                h -= calculateTabAreaHeight(tabPlacement, runCount, maxTabHeight);
                if (tabsOverlapBorder) {
                    h += tabAreaInsets.top;
                }
                break;
            case TOP:
            default:
                y += calculateTabAreaHeight(tabPlacement, runCount, maxTabHeight);
                if (tabsOverlapBorder) {
                    y -= tabAreaInsets.bottom;
                }
                h -= (y - insets.top);
        }

        paintContentBorderTopEdge(g, tabPlacement, selectedIndex, x, y, w, h);
        paintContentBorderLeftEdge(g, tabPlacement, selectedIndex, x, y, w, h);
        paintContentBorderBottomEdge(g, tabPlacement, selectedIndex, x, y, w, h);
        paintContentBorderRightEdge(g, tabPlacement, selectedIndex, x, y, w, h);
    }

    @Override
    protected void paintContentBorderLeftEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {
        g.setColor(SELECT_COLOR);
        g.drawLine(x, y, x, y + h - 2);
    }

    @Override
    protected void paintContentBorderTopEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {
        g.setColor(SELECT_COLOR);
        g.drawLine(x, y, x + w - 2, y);
    }

    @Override
    protected void paintContentBorderRightEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {
        g.setColor(SELECT_COLOR);
        g.drawLine(x + w - 1, y, x + w - 1, y + h - 1);
    } 

    @Override
    protected void paintContentBorderBottomEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {
        g.setColor(SELECT_COLOR);
        g.drawLine(x, y + h - 1, x + w - 1, y + h - 1);
    }

    @Override
    protected void paintFocusIndicator(Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected) {
    }

    @Override
    protected int calculateTabWidth(int tabPlacement, int tabIndex, FontMetrics metrics) {
        return super.calculateTabWidth(tabPlacement, tabIndex, metrics) +64; 
    }

    @Override
    protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
        return super.calculateTabHeight(tabPlacement, tabIndex, fontHeight) +5 ;
    }
}

class UI_PrevNextButton extends BasicButtonUI {
	private final static Dimension BTN_WIDTH_HEIGHT = new Dimension(40, 24);
	private Color SELECT_COLOR = new Color(0xffd0cd);
	
    @Override
    public void installUI (JComponent c) {
        super.installUI(c);
        AbstractButton button = (AbstractButton) c;
        button.setOpaque(false);
        button.setBorder(new EmptyBorder(5, 15, 5, 15));
        button.setPreferredSize(BTN_WIDTH_HEIGHT);
        button.setFont(new Font("Calibri", Font.PLAIN, 15));
        button.setBackground(SELECT_COLOR);
    }

    @Override
    public void paint (Graphics g, JComponent c) {
        AbstractButton b = (AbstractButton) c;
        paintBackground(g, b, b.getModel().isPressed() ? 2 : 0);
        super.paint(g, c);
    }

    private void paintBackground (Graphics g, JComponent c, int yOffset) {
        Dimension size = c.getSize();
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(c.getBackground().PINK);
        g.fillRoundRect(0, yOffset, size.width, size.height - yOffset, 10, 10);
        g.setColor(c.getBackground());
        g.fillRoundRect(0, yOffset, size.width, size.height + yOffset - 5, 10, 10);
    }
}

class UI_ScrollBar extends BasicScrollBarUI {
	private static final int thumbWidth = 7;
	private static final float opaque = 0.8f;
	private static final Color PINK = Color.PINK;
	private static final Color WHITE = Color.WHITE;
	
	@Override
	protected void configureScrollBarColors() {
		setThumbBounds(0, 0, 3, 10);
	}

	@Override
	public Dimension getPreferredSize(JComponent c) {
		c.setPreferredSize(new Dimension(thumbWidth, thumbWidth));
		return super.getPreferredSize(c);
	}

	public void paintTrack(Graphics g, JComponent c, Rectangle trackBounds) {
		Graphics2D g2 = (Graphics2D) g;
		GradientPaint gp = null;
		if (this.scrollbar.getOrientation() == JScrollBar.VERTICAL) {
			gp = new GradientPaint(0, 0, WHITE, 0, trackBounds.height, WHITE);
		}
		if (this.scrollbar.getOrientation() == JScrollBar.HORIZONTAL) {
			gp = new GradientPaint(0, 0, WHITE, trackBounds.width, 0, WHITE);
		}
		g2.setPaint(gp);
		g2.fillRect(trackBounds.x, trackBounds.y, trackBounds.width, trackBounds.height);
		if (trackHighlight == BasicScrollBarUI.DECREASE_HIGHLIGHT)
			this.paintDecreaseHighlight(g);
		if (trackHighlight == BasicScrollBarUI.INCREASE_HIGHLIGHT)
			this.paintIncreaseHighlight(g);
	}

	@Override
	protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
		g.translate(thumbBounds.x, thumbBounds.y);
		g.setColor(PINK);
		g.drawRoundRect(0, 0, thumbBounds.width - 1, thumbBounds.height - 1, 5, 5);
		Graphics2D g2 = (Graphics2D) g;
		RenderingHints rh = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		g2.addRenderingHints(rh);
		g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, opaque));
		g2.setPaint(
				new GradientPaint(c.getWidth() / 2, 1, PINK, c.getWidth() / 2, c.getHeight(), PINK));
		g2.fillRoundRect(0, 0, thumbBounds.width - 1, thumbBounds.height - 1, 5, 5);
	}

	@Override
	protected JButton createIncreaseButton(int orientation) {
		JButton button = new JButton();
		button.setBorderPainted(true);
		button.setContentAreaFilled(true);
		button.setBorder(null);
		return button;
	}

	@Override
	protected JButton createDecreaseButton(int orientation) {
		JButton button = new JButton();
		button.setBorderPainted(true);
		button.setContentAreaFilled(true);
		button.setFocusable(false);
		button.setBorder(null);
		return button;
	}
}

class UI_SelectButton extends BasicButtonUI {
	private final static Dimension BTN_WIDTH_HEIGHT = new Dimension(80, 30);
	private Color SELECT_COLOR = new Color(0xffd0cd);
	
    @Override
    public void installUI (JComponent c) {
        super.installUI(c);
        AbstractButton button = (AbstractButton) c;
        button.setOpaque(false);
        button.setBorder(new EmptyBorder(5, 15, 5, 15));
        button.setPreferredSize(BTN_WIDTH_HEIGHT);
        button.setFont(new Font("Calibri", Font.PLAIN, 15));
        button.setBackground(SELECT_COLOR);
    }

    @Override
    public void paint (Graphics g, JComponent c) {
        AbstractButton b = (AbstractButton) c;
        paintBackground(g, b, b.getModel().isPressed() ? 2 : 0);
        super.paint(g, c);
    }

    private void paintBackground (Graphics g, JComponent c, int yOffset) {
        Dimension size = c.getSize();
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(c.getBackground().PINK);
        g.fillRoundRect(0, yOffset, size.width, size.height - yOffset, 10, 10);
        g.setColor(c.getBackground());
        g.fillRoundRect(0, yOffset, size.width, size.height + yOffset - 5, 10, 10);
    }
}

class UI_SubTabbedPane extends BasicTabbedPaneUI {

    private boolean tabsOverlapBorder = UIManager.getBoolean("TabbedPane.tabsOverlapBorder");

    private Color SELECT_COLOR = new Color(0xffd0cd);
    private Color N_SELECT_COLOR = Color.WHITE;

    @Override
    protected void paintTabBorder(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
    }

    @Override
    protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
        Graphics2D g2d = (Graphics2D) g;
        GradientPaint gradient;
        switch (tabPlacement) {
            case LEFT:
                if (isSelected) {
                    gradient = new GradientPaint(x + 1, y, SELECT_COLOR, x + w, y, Color.WHITE, true);
                } else {
                    gradient = new GradientPaint(x + 1, y, N_SELECT_COLOR, x + w, y, Color.WHITE, true);
                }
                g2d.setPaint(gradient);
                g.fillRect(x + 1, y + 1, w - 1, h - 2);
                break;
            case RIGHT:
                if (isSelected) {
                    gradient = new GradientPaint(x + w, y, SELECT_COLOR, x + 1, y, Color.WHITE, true);
                } else {
                    gradient = new GradientPaint(x + w, y, N_SELECT_COLOR, x + 1, y, Color.WHITE, true);
                }
                g2d.setPaint(gradient);
                g.fillRect(x, y + 1, w - 1, h - 2);
                break;
            case BOTTOM:
                if (isSelected) {
                    gradient = new GradientPaint(x + 1, y + h, SELECT_COLOR, x + 1, y, Color.WHITE, true);
                } else {
                    gradient = new GradientPaint(x + 1, y + h, N_SELECT_COLOR, x + 1, y, Color.WHITE, true);
                }
                g2d.setPaint(gradient);
                g.fillRect(x + 1, y, w - 2, h - 1);
                break;
            case TOP:
            default:
                if (isSelected) {
                    gradient = new GradientPaint(x + 1, y, SELECT_COLOR, x + 1, y + h, Color.WHITE, true);
                } else {
                    gradient = new GradientPaint(x + 1, y, N_SELECT_COLOR, x + 1, y + h, Color.WHITE, true);
                }
                g2d.setPaint(gradient);
                g2d.fillRect(x + 1, y + 1, w - 2, h - 1);
        }
    }

    @Override
    protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex) {
        int width = tabPane.getWidth();
        int height = tabPane.getHeight();
        Insets insets = tabPane.getInsets();
        Insets tabAreaInsets = getTabAreaInsets(tabPlacement);

        int x = insets.left;
        int y = insets.top;
        int w = width - insets.right - insets.left;
        int h = height - insets.top - insets.bottom;

        switch (tabPlacement) {
            case LEFT:
                x += calculateTabAreaWidth(tabPlacement, runCount, maxTabWidth);
                if (tabsOverlapBorder) {
                    x -= tabAreaInsets.right;
                }
                w -= (x - insets.left);
                break;
            case RIGHT:
                w -= calculateTabAreaWidth(tabPlacement, runCount, maxTabWidth);
                if (tabsOverlapBorder) {
                    w += tabAreaInsets.left;
                }
                break;
            case BOTTOM:
                h -= calculateTabAreaHeight(tabPlacement, runCount, maxTabHeight);
                if (tabsOverlapBorder) {
                    h += tabAreaInsets.top;
                }
                break;
            case TOP:
            default:
                y += calculateTabAreaHeight(tabPlacement, runCount, maxTabHeight);
                if (tabsOverlapBorder) {
                    y -= tabAreaInsets.bottom;
                }
                h -= (y - insets.top);
        }
        paintContentBorderTopEdge(g, tabPlacement, selectedIndex, x, y, w, h);
        paintContentBorderLeftEdge(g, tabPlacement, selectedIndex, x, y, w, h);
        paintContentBorderBottomEdge(g, tabPlacement, selectedIndex, x, y, w, h);
        paintContentBorderRightEdge(g, tabPlacement, selectedIndex, x, y, w, h);
    }

    @Override
    protected void paintContentBorderLeftEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {
        g.setColor(SELECT_COLOR);
        g.drawLine(x, y, x, y + h - 2);
    }

    @Override
    protected void paintContentBorderTopEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {
        g.setColor(SELECT_COLOR);
        g.drawLine(x, y, x + w - 2, y);
    }

    @Override
    protected void paintContentBorderRightEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {
        g.setColor(SELECT_COLOR);
        g.drawLine(x + w - 1, y, x + w - 1, y + h - 1);
    }

    @Override
    protected void paintContentBorderBottomEdge(Graphics g, int tabPlacement, int selectedIndex, int x, int y, int w, int h) {
        g.setColor(SELECT_COLOR);
        g.drawLine(x, y + h - 1, x + w - 1, y + h - 1);
    }

    @Override
    protected void paintFocusIndicator(Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected) {
    }

    @Override
    protected int calculateTabWidth(int tabPlacement, int tabIndex, FontMetrics metrics) {
        return super.calculateTabWidth(tabPlacement, tabIndex, metrics) +124;
    }

    @Override
    protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
        return super.calculateTabHeight(tabPlacement, tabIndex, fontHeight) +5 ;
    }

}






