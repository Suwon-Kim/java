class HashCodeEx2 {
	public static void main(String[] args)	{
		/*
			String
			-> a.equals(b) �� true�� ���
			-> a.hashCode() == b.hashCode()
		*/
		System.out.println("�ƹݶ�".hashCode());
		System.out.println("�ҳ�Ÿ".hashCode());
		System.out.println("�ƹݶ�".hashCode());
	}
}
