class StringToInt {
	public static void main(String[] args)	{
		int n1 = Integer.parseInt("123");	//123
		// int n2 = Integer.parseInt("abc");	// ��ȯ�� �Ұ���
		double d1 = Double.parseDouble("3.14");
	}
}
