package kr.ac.blue;

import kr.ac.green.Some;

public class UseSome {
	private Some some;
	public void print() {
		some = new Some();
		System.out.println(some.str2);
//		System.out.println(some.str);
	}
}
