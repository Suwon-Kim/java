package kr.ac.green.fourth;

public interface IPressable {
	void buttonPressed();
}
