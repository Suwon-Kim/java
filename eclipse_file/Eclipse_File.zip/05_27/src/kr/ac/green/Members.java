package kr.ac.green;

import java.util.Vector;

public class Members {
	private String id;
	private String pw;
	private String name;
	private String nickNae;
	private String gender;
}
